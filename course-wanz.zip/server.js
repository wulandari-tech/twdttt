require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const methodOverride = require('method-override');
const session = require('express-session');
const flash = require('connect-flash');

const app = express();

const mongoURI = process.env.MONGODB_URI || '=mongodb+srv://zanssxploit:pISqUYgJJDfnLW9b@cluster0.fgram.mongodb.net/wfc?retryWrites=true&w=majority';
mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB Connected Successfully'))
.catch(err => console.error('MongoDB Connection Error:', err));


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(methodOverride('_method'));

app.use(session({
    secret: process.env.SESSION_SECRET || 'aVeryStrongAndLongSecretKeyForWFC',
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        // secure: process.env.NODE_ENV === 'production', // Aktifkan di produksi dengan HTTPS
        maxAge: 1000 * 60 * 60 * 24 // 1 hari
    }
}));

app.use(flash());

app.use((req, res, next) => {
    res.locals.currentUser = req.user; // Asumsi Anda akan menggunakan Passport.js nanti
    res.locals.success_msg = req.flash('success');
    res.locals.error_msg = req.flash('error');
    res.locals.pageTitle = 'WFC Course'; // Judul default jika tidak di-override
    res.locals.currentPath = req.path; // Untuk navigasi aktif
    next();
});


const indexRoutes = require('./routes/index');
const courseRoutes = require('./routes/courses');
const adminRoutes = require('./routes/admin');


app.use('/', indexRoutes);
app.use('/courses', courseRoutes);
app.use('/admin', adminRoutes);


app.use((req, res, next) => {
    res.status(404).render('error', {
        pageTitle: '404 - Halaman Tidak Ditemukan',
        heading: 'Oops! Halaman Tidak Ditemukan',
        message: 'Maaf, halaman yang Anda cari sepertinya tidak ada atau telah dipindahkan.'
    });
});


app.use((err, req, res, next) => {
    console.error("GLOBAL ERROR HANDLER:", err.stack);
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Terjadi kesalahan internal pada server.';
    res.status(statusCode).render('error', {
        pageTitle: `Error ${statusCode}`,
        heading: `Oops! Terjadi Kesalahan Server (${statusCode})`,
        message: message,
        error: process.env.NODE_ENV !== 'production' ? err : {}
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`WFC Course Server running on http://localhost:${PORT}`);
});