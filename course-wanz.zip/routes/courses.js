const express = require('express');
const router = express.Router();
const mongoose = require('mongoose'); // Diperlukan untuk ObjectId.isValid
const Course = require('../models/course');
// const Lesson = require('../models/Lesson'); // Tidak secara eksplisit diperlukan di sini jika hanya populate

// Daftar semua kursus yang dipublikasikan (GET)
router.get('/', async (req, res, next) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 9;
        const skip = (page - 1) * limit;

        const query = { isPublished: true };
        // Tambahkan filter berdasarkan kategori atau pencarian jika ada
        if (req.query.category) {
            query.category = req.query.category;
        }
        if (req.query.q) {
            query.title = { $regex: req.query.q, $options: 'i' }; // Pencarian case-insensitive
        }

        const courses = await Course.find(query)
            .sort({ createdAt: -1 }) // Urutkan berdasarkan terbaru
            .skip(skip)
            .limit(limit)
            .select('-lessons'); // Jangan ambil detail lessons di daftar kursus untuk performa

        const totalCourses = await Course.countDocuments(query);
        const totalPages = Math.ceil(totalCourses / limit);

        res.render('courses/index', {
            pageTitle: 'Semua Kursus',
            courses,
            currentPage: page,
            totalPages,
            limit,
            currentQuery: req.query,
            breadcrumbs: [
                { name: 'Beranda', link: '/' },
                { name: 'Kursus', link: '/courses' }
            ]
        });
    } catch (err) {
        console.error("Error di GET /courses (daftar):", err);
        next(err); // Lempar ke global error handler
    }
});

// Detail satu kursus (GET)
router.get('/:id', async (req, res, next) => {
    try {
        const courseId = req.params.id;

        if (!mongoose.Types.ObjectId.isValid(courseId)) {
            const err = new Error('Format ID Kursus tidak valid.');
            err.statusCode = 400;
            return next(err);
        }

        const course = await Course.findOne({ _id: courseId, isPublished: true })
            .populate({
                path: 'lessons',
                options: { sort: { order: 1, createdAt: 1 } } // Urutkan pelajaran
            });

        if (!course) {
            const err = new Error('Kursus tidak ditemukan atau belum dipublikasikan.');
            err.statusCode = 404;
            return next(err);
        }

        res.render('courses/show', {
            pageTitle: course.title,
            course,
            breadcrumbs: [
                { name: 'Beranda', link: '/' },
                { name: 'Kursus', link: '/courses' },
                { name: course.title, link: `/courses/${course._id}` }
            ]
        });
    } catch (err) {
        console.error(`Error di GET /courses/${req.params.id} (detail):`, err);
        next(err);
    }
});

// Menampilkan satu pelajaran dari kursus (GET)
router.get('/:courseId/lessons/:lessonId', async (req, res, next) => {
    try {
        const { courseId, lessonId } = req.params;

        if (!mongoose.Types.ObjectId.isValid(courseId) || !mongoose.Types.ObjectId.isValid(lessonId)) {
            const err = new Error('Format ID Kursus atau Pelajaran tidak valid.');
            err.statusCode = 400;
            return next(err);
        }

        const course = await Course.findOne({ _id: courseId, isPublished: true })
            .populate({
                path: 'lessons',
                options: { sort: { order: 1, createdAt: 1 } }
            });

        if (!course) {
            const err = new Error('Kursus tidak ditemukan atau belum dipublikasikan.');
            err.statusCode = 404;
            return next(err);
        }

        const lesson = course.lessons.find(l => l._id.toString() === lessonId);

        if (!lesson) {
            const err = new Error('Pelajaran tidak ditemukan dalam kursus ini.');
            err.statusCode = 404;
            return next(err);
        }

        res.render('courses/lesson', {
            pageTitle: `${lesson.title} | ${course.title}`,
            course,
            lesson,
            breadcrumbs: [
                { name: 'Beranda', link: '/' },
                { name: 'Kursus', link: '/courses' },
                { name: course.title, link: `/courses/${course._id}` },
                { name: lesson.title, link: `/courses/${course._id}/lessons/${lesson._id}` }
            ]
        });
    } catch (err) {
        console.error(`Error di GET /courses/${req.params.courseId}/lessons/${req.params.lessonId}:`, err);
        next(err);
    }
});

module.exports = router;