document.addEventListener('DOMContentLoaded', () => {
    const tabLinks = document.querySelectorAll('.course-tabs .tab-link');
    const tabContents = document.querySelectorAll('.course-detail-body .tab-content');

    if (tabLinks.length > 0 && tabContents.length > 0) {
        tabLinks.forEach(link => {
            link.addEventListener('click', () => {
                const tabId = link.dataset.tab;

                tabLinks.forEach(l => l.classList.remove('active'));
                link.classList.add('active');

                tabContents.forEach(content => {
                    content.classList.remove('active');
                    if (content.id === tabId) {
                        content.classList.add('active');
                    }
                });
            });
        });
    }
});